
package factory;

public class FactoryExample {
    public static Product createProduct(String type) {
        if ("A".equals(type)) {
            return new ProductA();
        } else if ("B".equals(type)) {
            return new ProductB();
        }
        return null;
    }
}

interface Product {
    void create();
}

class ProductA implements Product {
    public void create() {
        System.out.println("Product A created!");
    }
}

class ProductB implements Product {
    public void create() {
        System.out.println("Product B created!");
    }
}
